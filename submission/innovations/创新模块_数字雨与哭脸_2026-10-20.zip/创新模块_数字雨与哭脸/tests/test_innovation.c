/*
 * 创新模块主机测试：数字雨锁屏 + 哭脸报错
 *   zig cc -std=c11 -I ..\tests\stubs -I ..\src\include -o test_innovation.exe ^
 *       ..\tests\test_innovation.c ..\tests\stubs\stm32f1xx_hal.c ^
 *       ..\src\lock_screen.c ..\src\cry_face.c ..\src\lcd1602.c ..\src\bsp_delay.c
 */
#include <stdio.h>
#include <string.h>

#include "stm32f1xx_hal.h"
#include "lcd1602.h"
#include "lock_screen.h"
#include "cry_face.h"

static int g_pass = 0;
static int g_fail = 0;

#define CHECK(cond, msg) do { \
  if (cond) { g_pass++; } \
  else { g_fail++; printf("  [FAIL] %s\n", msg); } \
} while (0)

static void test_cry_face(void)
{
  char line[16];

  printf("[1] 哭脸报错\n");

  memcpy(line, "12 ERROR        ", 16u);
  CHECK(cry_face_replace_error(line) == 1u, "识别并替换 ERROR");
  CHECK(line[3] == (char)CRY_FACE_SLOT, "哭脸放在原来 E 的位置（第 4 格）");
  CHECK(line[0] == ' ', "其余字符被清空，屏幕更简洁");

  memcpy(line, "READY           ", 16u);
  CHECK(cry_face_replace_error(line) == 0u, "READY 不受影响");
  CHECK(memcmp(line, "READY           ", 16u) == 0, "READY 内容保持不变");

  memcpy(line, "           ERROR", 16u);
  CHECK(cry_face_replace_error(line) == 1u, "处理行尾的 ERROR");
  CHECK(line[11] == (char)CRY_FACE_SLOT, "行尾替换位置正确");
}

static void test_lock_screen(void)
{
  char line[17];

  printf("[2] 数字雨锁屏\n");

  lcd1602_init();
  cry_face_init();
  lock_screen_init();

  CHECK(lock_screen_is_locked() == 1u, "默认处于锁屏");

  lock_screen_render();
  hal_test_lcd_read_line(0u, line);
  CHECK(strlen(line) <= 16u, "数字雨渲染不越界");

  hal_test_advance_ms(500u);
  lock_screen_tick(HAL_GetTick());
  CHECK(lock_screen_is_locked() == 1u, "运行中保持锁屏");

  CHECK(lock_screen_handle_key(0u, (1u << 2)) == 1u, "按 MODE 被锁屏消费");
  CHECK(lock_screen_is_locked() == 0u, "按 MODE 后解锁");

  hal_test_lcd_read_line(1u, line);
  CHECK(strstr(line, "READY") != NULL, "解锁后显示 READY");

  CHECK(lock_screen_handle_key(0u, (1u << 2) | (1u << 7)) == 0u,
        "计算中 MODE+← 串扰不会误锁屏");
  CHECK(lock_screen_is_locked() == 0u, "串扰时仍保持计算器界面");

  CHECK(lock_screen_handle_key(0u, (1u << 2)) == 1u, "干净 MODE 被消费");
  CHECK(lock_screen_is_locked() == 1u, "干净 MODE 重新上锁");

  lock_screen_tick(HAL_GetTick() + 1000u);
  CHECK(lock_screen_is_locked() == 1u, "数字雨继续运行不崩溃");
}

int main(void)
{
  printf("==== 创新模块测试 ====\n");
  test_cry_face();
  test_lock_screen();
  printf("==== 通过 %d 项，失败 %d 项 ====\n", g_pass, g_fail);
  return (g_fail == 0) ? 0 : 1;
}
